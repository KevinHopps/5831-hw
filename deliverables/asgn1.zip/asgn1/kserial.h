#include <pololu/orangutan.h>

extern void emptySendBuffer();
extern int spr(const char* fmt, ...);
